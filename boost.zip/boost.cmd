c:\windows\SYSTEM32\cleanmgr.exe /cDrive
sfc /scannow 